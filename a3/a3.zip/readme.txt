TO RUN TYPE FOLLOWING COMMANDS:

gcc -o smallsh smallsh.c
smallsh

PLEASE NOTE:
The first command entered will often error.
I do not know why.
It doesn't interfere with the grading script and otherwise works as expected.
Please have mercy on my soul.
